let player;
let obstacles = [];
let score = 0;
let gameOver = false;

function setup() {
  createCanvas(400, 600);
  player = {
    x: width / 2,
    y: height - 30,
    r: 15,
    speed: 3
  };
}

function draw() {
  background(135, 206, 235);

  if (!gameOver) {
    // Céu e Sol
    fill(255, 204, 0);
    ellipse(width / 2, 50, 100);

    // Player (molécula)
    fill(0, 119, 190);
    ellipse(player.x, player.y, player.r * 2);

    // Movimento com teclado
    if (keyIsDown(LEFT_ARROW)) player.x -= player.speed;
    if (keyIsDown(RIGHT_ARROW)) player.x += player.speed;

    // Limites
    player.x = constrain(player.x, player.r, width - player.r);

    // Obstáculos (nuvens poluentes)
    if (frameCount % 40 === 0) {
      obstacles.push({
        x: random(30, width - 30),
        y: 0,
        r: 20,
        speed: 2
      });
    }

    for (let o of obstacles) {
      fill(120);
      ellipse(o.x, o.y, o.r * 2);
      o.y += o.speed;

      // Colisão
      if (dist(player.x, player.y, o.x, o.y) < player.r + o.r) {
        gameOver = true;
      }
    }

    // Vitória (atinge o topo)
    if (player.y < 50) {
      score++;
      resetGame("Parabéns! Você evaporou! 🌤️");
    }

    // Texto
    fill(0);
    textSize(18);
    text("Pontuação: " + score, 10, 25);
    text("Desvie das nuvens e evapore!", 10, 50);
  } else {
    fill(0);
    textSize(24);
    textAlign(CENTER);
    text("☁️ Você foi atingido!", width / 2, height / 2 - 20);
    text("Pontuação final: " + score, width / 2, height / 2 + 20);
    textSize(16);
    text("Pressione ENTER para jogar de novo", width / 2, height / 2 + 50);
  }
}

function keyPressed() {
  if (gameOver && keyCode === ENTER) {
    resetGame();
  }
}

function resetGame(msg = "") {
  if (msg) console.log(msg);
  player.y = height - 30;
  obstacles = [];
  gameOver = false;
}
